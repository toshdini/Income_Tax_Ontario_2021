				ICOME TAX CALCULATION WITH PYCHART AND EXCEL SHEET
Hello, This program is created by me (Abdirahman Mohamed). In this README file, I will discuss the features 
of the program and how to use it (it is very simple!!).

First things First, you must have a working IDE that showcases any plots or is integratred with external python 
modules. The program uses two main external libraries; Matplotlib and Panda. you must have it installed on your
device to work it properly. 

Main features: 
- Designed to utilize OOP concepts (classes, Functions, Inhertance, etc)
- simple and easy to understand name concept used on variables/classes/funtions/objects.
- Program is flexible and can be modified for future uses.
- Contains fair amount of comments to clarify some aspects of the program.
- Output will be two main feature; 1: an excel file, containing a income tax table. 2: Pie chart showcasing 
(Net pay, Total Tax Payed).  
- And finaly, it is very visually apealing (adequatre amount of spaces, proper indentaions)

HOW TO USE:
1. Unizp  the program, using either 7zip or winrar (both free to download).
2. open the 'main.py' on your IDE or the cmd.
3. run the progam and input "Income salary for 2021".
